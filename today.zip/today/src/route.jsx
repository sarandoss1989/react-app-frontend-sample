import React from 'react'
import {
  BrowserRouter as Router,
  Route,
  } from 'react-router-dom';
import Home from './components/home';
import Results from './components/results';


const Routes =() => (
    
    <Router basename={'crossword/cludein'}>
    <div>
     
      <Route exact path="/" render={(props) =><Home/>} />
      <Route path="/article/:id" render={(props) =><Results name={props}/>} />
     
    </div>
  </Router>
    
)



export default Routes;
